import "./styles.css";
import axios from "axios";
import { useEffect, useState } from "react";
import Header from "./components/Header";

export default function App() {
  const [user, setUser] = useState();
  useEffect(() => {
    const fetchData = async () => {
      let res = "";
      try {
        res = await axios.get("https://randomuser.me/api/");
      } catch (err) {
        console.log("Error :", err);
      }
      if (res.status === 200) {
        setUser(res.data.results[0]);
      }
    };
    fetchData();
  }, []);
  return (
    <>
      {user && (
        <Header
          name={user.name}
          email={user.email}
          image={user.picture.large}
          phone={user.phone}
          location={user.location}
        />
      )}
    </>
  );
}
