import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

const bull = (
  <Box
    component="span"
    sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
  >
    •
  </Box>
);

const Header = ({ name, image, email, phone, location }) => {
  return (
    <>
      <Box sx={{ minWidth: 275 }}>
        <Card variant="outlined">
          <CardContent>
            <img className="image" src={image} loading="lazy" />
            <Typography variant="h5" component="div">
              {name.title} {name.first} {name.last}
            </Typography>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondary"
              gutterBottom
            >
              {email}
            </Typography>
            <Typography color="text.secondary"></Typography>
            <Typography variant="body2">{phone}</Typography>
            <Typography
              sx={{ fontSize: 14 }}
              color="text.secondry"
              gutterBottom
            >
              {location.street.name} {location.city} {location.state}{" "}
              {location.country}
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </>
  );
};

export default Header;
